"""Local-only simulator helpers."""
